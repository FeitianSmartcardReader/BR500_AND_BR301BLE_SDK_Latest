@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem =============================================================================
rem  Feitian bR301BLE Bluetooth Smart Card Reader Driver - Installer
rem =============================================================================

echo.
echo ====================================================================
echo   Feitian bR301BLE Driver Installer
echo ====================================================================
echo.

rem ---- Check administrator privileges ------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Administrator privileges required
    echo.
    echo Please right-click this file and select "Run as administrator"
    echo.
    pause
    exit /b 1
)

rem ---- Check required files ----------------------------------------------
if not exist "_ftinstall.exe" (
    echo [ERROR] _ftinstall.exe not found
    echo Installation files are missing
    pause
    exit /b 1
)

if not exist "ftbleccid.inf" (
    echo [ERROR] ftbleccid.inf not found
    echo Driver files are missing
    pause
    exit /b 1
)

if not exist "ftbleccid.dll" (
    echo [ERROR] ftbleccid.dll not found
    echo Driver files are missing
    pause
    exit /b 1
)

if not exist "ftbleccid.cat" (
    echo [ERROR] ftbleccid.cat not found
    echo Driver files are missing
    pause
    exit /b 1
)

rem ---- Install driver ----------------------------------------------------
echo Installing driver...
echo.

_ftinstall.exe install "%~dp0ftbleccid.inf"

if %errorlevel% equ 0 (
    echo.
    echo ====================================================================
    echo   Installation successful!
    echo ====================================================================
    echo.
    echo The smart card reader is now ready to use.
    echo.
    echo You should see in Device Manager - Smart card readers:
    echo   Feitian bR301BLE
    echo.
) else (
    echo.
    echo ====================================================================
    echo   Installation failed
    echo ====================================================================
    echo.
    echo Please check:
    echo - Is the Bluetooth reader paired?
    echo - Are you running as administrator?
    echo - Is Windows 11 ARM64?
    echo.
)

pause
exit /b %errorlevel%
