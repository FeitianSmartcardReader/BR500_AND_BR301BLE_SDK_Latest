@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem =============================================================================
rem  Feitian bR301BLE Bluetooth Smart Card Reader Driver - Uninstaller
rem =============================================================================

echo.
echo ====================================================================
echo   Feitian bR301BLE Driver Uninstaller
echo ====================================================================
echo.

rem ---- Check administrator privileges ------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Administrator privileges required
    echo.
    echo Please right-click this file and select "Run as administrator"
    echo.
    pause
    exit /b 1
)

rem ---- Check installer ---------------------------------------------------
if not exist "_ftinstall.exe" (
    echo [ERROR] _ftinstall.exe not found
    echo Installation files are missing
    pause
    exit /b 1
)

rem ---- Confirm uninstall -------------------------------------------------
echo Warning: This will uninstall Feitian bR301BLE driver
echo.
set /p confirm="Confirm uninstall? (Y/N): "
if /i not "%confirm%"=="Y" (
    echo Cancelled
    pause
    exit /b 0
)

rem ---- Uninstall driver --------------------------------------------------
echo.
echo Uninstalling driver...
echo.

_ftinstall.exe remove

if %errorlevel% equ 0 (
    echo.
    echo ====================================================================
    echo   Uninstall successful!
    echo ====================================================================
    echo.
    echo The driver has been removed from the system.
    echo.
    echo Note: Bluetooth pairing is not removed.
    echo       You can manually unpair in Bluetooth settings if needed.
    echo.
) else (
    echo.
    echo ====================================================================
    echo   Uninstall failed
    echo ====================================================================
    echo.
)

pause
exit /b %errorlevel%
