=============================================================================
  Feitian bR301BLE Bluetooth Smart Card Reader Driver

  Version: 1.0.0.0
  Date: 2026-09-17
  System: Windows 11 ARM64
=============================================================================

## Installation Steps

1. Pair the Bluetooth reader

   Open "Settings -> Bluetooth & devices -> Add device"

   Select the reader (usually shown as FT_xxxxx)

2. Install driver

   Right-click install.bat and select "Run as administrator"

   Follow the prompts to complete installation

3. Verify installation

   Open "Device Manager -> Smart card readers"

   You should see: Feitian bR301BLE

## Uninstall

Right-click uninstall.bat and select "Run as administrator"

Note: Bluetooth pairing is not removed, manually unpair in Bluetooth
settings if needed

## File Description

install.bat      - Installation script
uninstall.bat    - Uninstall script
_ftinstall.exe   - Installer executable (called by scripts, do not run directly)
ftbleccid.inf    - Driver information file
ftbleccid.dll    - Driver binary (ARM64)
ftbleccid.cat    - Driver catalog signature

## System Requirements

- Windows 11 ARM64 (e.g., Surface Pro X / Surface Laptop 7)
- Bluetooth 4.0 or higher
- Administrator privileges

## FAQ

Q: Reader not showing after installation?
A: 1. Confirm the reader is paired and connected
   2. In Device Manager, right-click "Smart card readers", select
      "Scan for hardware changes"
   3. Restart the computer

Q: Can I use this on x64 Windows?
A: No, this driver only supports ARM64 architecture

Q: What certificate is required for signing?
A: Production release requires EV code signing certificate and Microsoft
   Partner Center attestation signing. Test version can use standard code
   signing certificate.

## Technical Support

For technical support, please contact Feitian

## Known Limitations

- Single APDU transfer should not exceed 8KB (10KB may timeout)
- Bluetooth reader must be paired before installation
- ARM64 architecture only

## Version History

1.0.0.0 (2026-09-17)
  - Initial release
  - Windows 11 ARM64 support
  - Full CCID protocol implementation
  - BLE transport layer optimization
  - Timeout budget: 20 seconds
  - Tested: 62/69 functional tests + 36 unit tests + 9 stress phases
