*Please confirm your bluetooth module on your PC support BLE Technology

2019/03/20
	Update driver, add new bR301BLE and bR500 support, which upgraded the bluetooth module, change to new UUID
	Fix bug when disconnect the reader
2016/04/20
	The install manual will publish end of this month
2016/03/09
	Feitian publish two new product with Bluetooth BLE technology, bR301_BLE is chip card reader with BLE technology, and bR500 is contactless card with BLE technology, they are both is PC/SC reader, the driver also is CCID compatible, the driver using for windows which allow user to do bluetooth connection on windows. The driver is CCID driver which based on bluetooth framework, and on high level, user can call WINSCARD API to do opeartion reader.
	Any questions, contact FEITIAN anytime, mail is ben@ftsafe.com, thanks